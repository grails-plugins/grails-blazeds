package flex.rds.server;

import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import java.util.Vector;

@SuppressWarnings({"unchecked", "rawtypes"})
class MetaHeader {

	final Vector _meta = new Vector();
	private String encoding;

	MetaHeader(String encoding) {
		this.encoding = encoding;
	}

	public void clear() {
		_meta.clear();
	}

	public String getString(int index) {
		Object obj = _meta.elementAt(index);
		if (!(obj instanceof byte[])) {
			return null;
		}
		try {
			return new String((byte[])obj, encoding);
		}
		catch (UnsupportedEncodingException e) {
			throw new IllegalStateException(e.getMessage());
		}
	}

	public byte[] getBytes(int index) {
		Object obj = _meta.elementAt(index);
		if (obj instanceof byte[]) {
			return (byte[])obj;
		}
		if (obj instanceof String) {
			return getBytes((String)obj);
		}
		return null;
	}

	public int size() {
		return _meta.size();
	}

	public Enumeration enumerate() {
		return _meta.elements();
	}

	public void add(byte[] meta) {
		_meta.addElement(meta);
	}

	public void add(String meta) {
		_meta.addElement(meta);
	}

	public void set(int index, byte meta[]) {
		if (_meta.size() == index) {
			add(meta);
		}
		else {
			_meta.setElementAt(meta, index);
		}
	}

	public void set(int index, String meta) {
		if (_meta.size() == index) {
			add(meta);
		}
		else {
			_meta.setElementAt(meta, index);
		}
	}

	public byte[] getBytes(String str) {
		try {
			return str.getBytes(encoding);
		}
		catch (UnsupportedEncodingException e) {
			throw new IllegalStateException(e.getMessage());
		}
	}

	@Override
	public String toString() {
		return _meta.toString();
	}
}
