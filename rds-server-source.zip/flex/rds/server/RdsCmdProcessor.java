package flex.rds.server;

import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;

public abstract class RdsCmdProcessor {

	public void init(Servlet parent) throws ServletException {
		_parent = parent;
		init();
	}

	@SuppressWarnings("unused")
	protected void init() throws ServletException {
		// empty
	}

	public abstract void processCmd(RdsRequest rdsrequest, RdsResponse rdsresponse) throws IOException, ServletException;

	protected ServletConfig getServletConfig() {
		return _parent.getServletConfig();
	}

	protected ServletContext getServletContext() {
		return getServletConfig().getServletContext();
	}

	protected Servlet getServlet() {
		return _parent;
	}

	private Servlet _parent;
}
