package flex.rds.server;

public class RdsGlobals {
	String ATTR_CONFIG_DATA = "rds.properties";
	String RDS_CLIENT_ENCODING = "utf-8";
	int SERVER_MAJOR_VERSION = 1;
}
