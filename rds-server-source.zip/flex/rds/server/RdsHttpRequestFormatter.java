package flex.rds.server;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;

import flex.rds.server.util.RB;

public class RdsHttpRequestFormatter {

	private String encoding;
	private final MetaHeader _meta;

	RdsHttpRequestFormatter() {
		encoding = "utf-8";
		_meta = new MetaHeader(encoding);
	}

	void parseRequest(HttpServletRequest request) throws IOException {
		if (_meta.size() > 0)
			_meta.clear();
		InputStream in = request.getInputStream();
		byte buf[] = new byte[255];
		ByteArrayOutputStream ba = new ByteArrayOutputStream();
		for (int numRead = in.read(buf); numRead != -1; numRead = in.read(buf))
			ba.write(buf, 0, numRead);

		ba.flush();
		parse(ba.toByteArray());
	}

	public void parse(byte args[]) {
		try {
			int index = indexOf(':', args, 0);
			if (index == -1)
				throw new RuntimeException(RB.getString(this, "RdsHttpRequestFormatter.InvalidArg", new String(args)));
			int length = Integer.parseInt(new String(args, 0, index, "utf-8"));
			int argCount = length;
			int offset = index;
			for (int i = 0; i < argCount; i++) {
				offset = offset + 1 + 4;
				index = indexOf(':', args, offset);
				if (index == -1)
					throw new RuntimeException(RB.getString(this, "RdsHttpRequestFormatter.InvalidArg", new String(args,
							offset, args.length - offset)));
				length = Integer.parseInt(new String(args, offset, index - offset, "utf-8"));
				offset += index - offset;
				_meta.add(getBytes(args, offset + 1, offset + length + 1));
				offset += length;
			}

		}
		catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			throw new IllegalStateException(e.getMessage());
		}
	}

	int indexOf(char ch, byte bytes[], int off) {
		for (int i = off; i < bytes.length; i++)
			if (bytes[i] == ch)
				return i;

		return -1;
	}

	private byte[] getBytes(byte b[], int start, int end) {
		int len = end - start;
		byte newb[] = new byte[len];
		if (b.length < start + len) {
			throw new IllegalStateException();
		}
		System.arraycopy(b, start, newb, 0, len);
		return newb;
	}

	public String getMetaString(int index) {
		return _meta.getString(index);
	}

	public byte[] getMetaBytes(int index) {
		return _meta.getBytes(index);
	}

	public int getMetaCount() {
		return _meta.size();
	}

	@SuppressWarnings("rawtypes")
	public Enumeration enumerateMetaData() {
		return _meta.enumerate();
	}

	@Override
	public String toString() {
		return _meta.toString();
	}
}
