package flex.rds.server;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;

import javax.servlet.ServletException;

public class RdsHttpResponseFormatter {

	ByteArrayOutputStream bout = new ByteArrayOutputStream();
	int returnCount;
	String errMessage;
	String encoding = "utf-8";

	public void add(String arg) {
		add(getBytes(arg));
	}

	public void add(byte buf[]) {
		try {
			bout.write(Integer.toString(buf.length).getBytes(encoding));
			bout.write(getBytes(":"));
			bout.write(buf);
			returnCount++;
		}
		catch (IOException e) {
			throw new RuntimeException(e.getMessage());
		}
	}

	public void setError(int errorCode, String message, String details) {
		returnCount = errorCode;
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		pw.println(message);
		if (details != null) {
			pw.println();
			pw.println(details);
		}
		pw.flush();
		errMessage = sw.toString();
	}

	public void setError(int errorCode, String message, Throwable th) {
		Throwable tmpRoot = th;
		Throwable root = null;
		if (th != null)
			while (root == null)
				if (tmpRoot instanceof ServletException) {
					ServletException se = (ServletException)tmpRoot;
					if (se.getRootCause() == null)
						root = se;
					else
						tmpRoot = se.getRootCause();
				}
				else {
					root = tmpRoot;
				}
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		pw.flush();
		setError(errorCode, message, sw.toString());
	}

	public void setError(String message, Throwable th) {
		setError(-1, message, th);
	}

	public int getReturnCount() {
		return returnCount;
	}

	public byte[] getBytes(String str) {
		try {
			return str.getBytes(encoding);
		}
		catch (UnsupportedEncodingException e) {
			throw new IllegalStateException(e.getMessage());
		}
	}

	public byte[] getMessageBytes() {
		ByteArrayOutputStream out;
		try {
			out = new ByteArrayOutputStream();
			if (returnCount < 0) {
				out.write(getBytes(Integer.toString(getReturnCount())));
				out.write(getBytes(":"));
				out.write(getBytes(errMessage));
			}
			else {
				out.write(getBytes(Integer.toString(getReturnCount())));
				out.write(getBytes(":"));
				out.write(bout.toByteArray());
			}
		}
		catch (IOException e) {
			throw new IllegalStateException(e.getMessage());
		}
		return out.toByteArray();
	}
}
