package flex.rds.server;

import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;

public interface RdsRequest {
	String getUserName();
	String getPassword();
	String getMetaString(int i);
	@SuppressWarnings("rawtypes")
	Enumeration enumerateMetaData();
	HttpServletRequest getHttpServletRequest();
}
