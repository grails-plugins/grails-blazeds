package flex.rds.server;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;

class RdsRequestImpl implements RdsRequest {

	private final RdsHttpRequestFormatter _formatter = new RdsHttpRequestFormatter();
	private HttpServletRequest _request;

	RdsRequestImpl() {
		// default
	}

	final void init(HttpServletRequest req) throws IOException {
		_request = req;
		loadMetaData();
	}

	final void reset() {
		_request = null;
	}

	public final String getMetaString(int i) {
		return _formatter.getMetaString(i);
	}

	@SuppressWarnings("rawtypes")
	public final Enumeration enumerateMetaData() {
		return _formatter.enumerateMetaData();
	}

	public final String getUserName() {
		return _formatter.getMetaString(_formatter.getMetaCount() - 2);
	}

	public final String getPassword() {
		return _formatter.getMetaString(_formatter.getMetaCount() - 1);
	}

	public final HttpServletRequest getHttpServletRequest() {
		return _request;
	}

	private void loadMetaData() throws IOException {
		_formatter.parseRequest(_request);
	}
}
