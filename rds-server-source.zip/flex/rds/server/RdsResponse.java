package flex.rds.server;

import java.util.Enumeration;

import javax.servlet.http.HttpServletResponse;

public interface RdsResponse {
	void addMetaData(String s);
	String getMetaString(int i);
	@SuppressWarnings("rawtypes")
	Enumeration enumerateMetaData();
	void setError(String s, Throwable throwable);
	void setError(Throwable throwable);
	void setError(String s);
	HttpServletResponse getHttpServletResponse();
}
