package flex.rds.server;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import flex.rds.server.util.RB;

@SuppressWarnings("rawtypes")
class RdsResponseImpl implements RdsResponse {

	private HttpServletResponse _response;
	private final MetaHeader _meta = new MetaHeader("utf-8");
	private String _errorMessage;
	private boolean _errorOccurred;
	private Throwable _error;
	private int _errorCode = -1;

	final void init(HttpServletResponse resp) {
		_response = resp;
	}

	final void finish() throws ServletException, IOException {
		try {
			RdsHttpResponseFormatter formatter = new RdsHttpResponseFormatter();
			if (errorOccurred()) {
				formatter.setError(_errorCode, _errorMessage, _error);
			}
			else {
				for (Enumeration metadataEnum = enumerateMetaData(); metadataEnum.hasMoreElements();) {
					Object obj = metadataEnum.nextElement();
					if (obj instanceof String)
						formatter.add((String)obj);
					else
						throw new IOException(RB.getString(this, "RdsServlet.UnsupportedType", obj.getClass().getName()));
				}

			}
			byte bytes[] = formatter.getMessageBytes();
			_response.setContentType("text/html");
			ServletOutputStream out = _response.getOutputStream();
			out.write(bytes);
			_response.flushBuffer();
		}
		catch (IOException e) {
			throw e;
		}
		catch (Exception e) {
			throw new ServletException(e);
		}
	}

	final void reset() {
		_response = null;
		_error = null;
		_errorMessage = null;
		_errorOccurred = false;
	}

	public final void addMetaData(String metaString) {
		_meta.add(metaString);
	}

	public final String getMetaString(int index) {
		return _meta.getString(index);
	}

	public final Enumeration enumerateMetaData() {
		return _meta.enumerate();
	}

	public final HttpServletResponse getHttpServletResponse() {
		return _response;
	}

	public final void setError(int errorCode, String message, Throwable th) {
		_errorCode = errorCode;
		_errorMessage = message;
		_error = th;
		_errorOccurred = true;
	}

	public final void setError(String message, Throwable th) {
		setError(-1, message, th);
	}

	public final void setError(Throwable th) {
		setError(-1, th.getMessage(), th);
	}

	public final void setError(String message) {
		setError(message, new ServletException(message));
	}

	Throwable getError() {
		return _error;
	}

	boolean errorOccurred() {
		return _errorOccurred;
	}
}
