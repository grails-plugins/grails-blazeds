package flex.rds.server;

import java.io.IOException;
import java.util.List;
import java.util.Vector;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import flex.messaging.MessageBroker;
import flex.messaging.security.LoginCommand;
import flex.messaging.security.LoginManager;
import flex.rds.server.util.Encryptor;
import flex.rds.server.util.RB;

@SuppressWarnings({"serial", "rawtypes", "unchecked"})
public abstract class RdsServlet extends HttpServlet {

	private List rdsRoles;
	private MessageBroker messageBroker;
	private boolean useSecurityModel;

	@Override
	public void init(ServletConfig config) throws ServletException {
		String messageBrokerID = config.getInitParameter("messageBrokerId");
		messageBroker = MessageBroker.getMessageBroker(messageBrokerID);
		if (messageBroker == null)
			throw new ServletException(RB.getString(this, "RdsServlet.MissingMessageBroker"));
		super.init(config);
		useSecurityModel = true;
		String initParam = config.getInitParameter("useAppserverSecurity");
		if ("false".equalsIgnoreCase(initParam))
			useSecurityModel = false;
		rdsRoles = new Vector();
		rdsRoles.add("rds");
	}

	protected MessageBroker getMessageBroker() {
		return messageBroker;
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		HttpServletRequest req;
		HttpServletResponse resp;
		try {
			req = request;
			resp = response;
		}
		catch (ClassCastException e) {
			throw new ServletException(RB.getString(this, "RdsServlet.NonHttp"));
		}
		RdsRequestImpl rdsReq = new RdsRequestImpl();
		RdsResponseImpl rdsResp = new RdsResponseImpl();
		rdsReq.init(req);
		rdsResp.init(resp);
		try {
			if (isSecure() && !checkAuthorization(rdsReq.getUserName(), rdsReq.getPassword())) {
				String errorMsg = RB.getString(this, "RdsServlet.AccessDenied");
				log(errorMsg);
				rdsResp.setError(-100, errorMsg, null);
				rdsResp.addMetaData("0");
			}
			else {
				processCmd(rdsReq, rdsResp);
			}
		}
		catch (Throwable th) {
			log(th.getMessage(), th);
			rdsResp.setError(th);
		}
		doPostProcessCmd(rdsReq, rdsResp);
	}

	protected abstract void processCmd(RdsRequest rdsrequest, RdsResponse rdsresponse) throws ServletException,
			IOException;

	private void doPostProcessCmd(RdsRequestImpl request, RdsResponseImpl response) throws IOException, ServletException {
		response.finish();
		request.reset();
		response.reset();
	}

	public boolean checkAuthorization(String username, String password) {
		return checkUsernamePassword(username, password);
	}

	protected boolean checkMessageBrokerAuthentication(String username, String password) {
		try {
			if (!useSecurityModel)
				return true;
			LoginManager lm;
			LoginCommand lc;
			lm = getMessageBroker().getLoginManager();
			lc = lm.getLoginCommand();
			if (lc == null)
				return false;
			java.security.Principal p = lm.getLoginCommand().doAuthentication(username, password);
			if (p == null)
				return false;
			return lm.checkRoles(p, rdsRoles);
		}
		catch (Throwable t) {
			return false;
		}
	}

	protected boolean checkUsernamePassword(String username, String pw) {
		return checkMessageBrokerAuthentication(username, Encryptor.decrypt(pw));
	}

	public boolean isSecure() {
		return true;
	}
}
