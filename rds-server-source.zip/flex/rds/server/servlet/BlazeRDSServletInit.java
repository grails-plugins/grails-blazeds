package flex.rds.server.servlet;

import java.util.HashMap;
import java.util.Map;

@SuppressWarnings("rawtypes")
public class BlazeRDSServletInit implements IRDSServletInit {
	public Map getServletCommandMap() {
		Map<String, Class<?>> result = new HashMap<String, Class<?>>();
		result.put("IDE_DEFAULT", IdeDefaultServlet.class);
		result.put("LCDS_INTROSPECTOR", FBServicesServlet.class);
		return result;
	}
}
