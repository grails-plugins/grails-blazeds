package flex.rds.server.servlet;

import java.io.IOException;

import javax.servlet.ServletException;

import flex.messaging.FlexContext;
import flex.messaging.MessageBroker;
import flex.messaging.log.Log;
import flex.messaging.log.Logger;
import flex.rds.server.RdsCmdProcessor;
import flex.rds.server.RdsRequest;
import flex.rds.server.RdsResponse;
import flex.rds.server.servlet.internal.JavaDestinationReader;
import flex.rds.server.servlet.internal.JavaIntrospector;
import flex.rds.server.servlet.internal.JavaIntrospectorUtil;
import flex.rds.server.servlet.internal.LCDSIntrospectionException;
import flex.rds.server.util.RB;

public class FBServicesServlet extends RdsCmdProcessorCompositeServlet {

	public static final String CMD_DISCOVER = "DISCOVER";
	public static final String CMD_INTROSPECT = "INTROSPECT";
	public static final String CHANNEL_INTROSPECT = "CHANNEL_INTROSPECT";
	private static final long serialVersionUID = 1L;
	private Logger logger;

	class ChannelIntrospectOperator extends RdsCmdProcessor {

		@Override
		public void processCmd(RdsRequest request, RdsResponse response) throws IOException, ServletException {
			String serviceId = request.getMetaString(1).trim();
			String introspectorContent = "";
			try {
				introspectorContent = JavaIntrospectorUtil.getDefaultChannels(messageBroker, serviceId);
			}
			catch (Exception e) {
				logger.error(e.getMessage(), e);
				response.setError(e.getMessage(), e);
				return;
			}
			response.addMetaData(introspectorContent);
		}

		private MessageBroker messageBroker;

		public ChannelIntrospectOperator(MessageBroker messageBroker) {
			this.messageBroker = messageBroker;
		}
	}

	class DiscoverOperator extends RdsCmdProcessor {

		@Override
		public void processCmd(RdsRequest request, RdsResponse response) throws IOException, ServletException {
			String xml = JavaDestinationReader.getDesinationsAsXMLString(messageBroker);
			response.addMetaData(xml);
		}

		private MessageBroker messageBroker;

		public DiscoverOperator(MessageBroker messageBroker) {
			this.messageBroker = messageBroker;
		}
	}

	class IntrospectOperator extends RdsCmdProcessor {

		@Override
		public void processCmd(RdsRequest request, RdsResponse response) throws IOException, ServletException {
			String destinationId = request.getMetaString(1).trim();
			String introspectorContent = "";
			try {
				introspectorContent = (new JavaIntrospector(messageBroker, destinationId)).getClassDataAsXMLString();
			}
			catch (LCDSIntrospectionException e) {
				logger.error(e.getMessage(), e);
				response.setError(e.getMessage(), e);
				return;
			}
			response.addMetaData(introspectorContent);
		}

		private MessageBroker messageBroker;

		public IntrospectOperator(MessageBroker messageBroker) {
			this.messageBroker = messageBroker;
		}
	}

	@Override
	protected void doInit() throws ServletException {
		logger = Log.getLogger("FBServices.Introspection");
		logger.info("LCDS java introspector servlet initializing");
		MessageBroker messageBroker = getMessageBroker();
		addCmdProcessor("INTROSPECT", new IntrospectOperator(messageBroker));
		addCmdProcessor("DISCOVER", new DiscoverOperator(messageBroker));
		addCmdProcessor("CHANNEL_INTROSPECT", new ChannelIntrospectOperator(messageBroker));
	}

	@Override
	protected void processCmd(RdsRequest request, RdsResponse response) throws ServletException, IOException {
		String operation = request.getMetaString(0).toUpperCase();
		RdsCmdProcessor rcp = getCmdProcessor(operation);
		if (rcp == null) {
			response.setError(RB.getString(this, "LCDSJavaIntrospectorServlet.UnsupportedOperation", operation));
			return;
		}

		FlexContext.setThreadLocalObjects(null, null, getMessageBroker(), request.getHttpServletRequest(),
				response.getHttpServletResponse(), getServletConfig());
		rcp.processCmd(request, response);
	}
}
