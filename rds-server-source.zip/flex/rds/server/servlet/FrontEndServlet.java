package flex.rds.server.servlet;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import flex.messaging.log.Log;
import flex.messaging.log.Logger;
import flex.rds.server.RdsHttpResponseFormatter;

public class FrontEndServlet extends HttpServlet {

	private static final long serialVersionUID = 0x117a2b9b5cf9e47eL;
	private Map<String, Servlet> _servlets = new HashMap<String, Servlet>();
	protected Logger logger;

	@SuppressWarnings({"rawtypes", "unchecked"})
	@Override
	public void init() throws ServletException {
		logger = Log.getLogger("RDS");
		Vector<String> initList = new Vector<String>();
		initList.add("flex.rds.server.servlet.BlazeRDSServletInit");
		initList.add("flex.rds.server.lcds.servlet.LCDSRDSServletInit");
		String extras = getServletConfig().getInitParameter("initServlets");
		if (extras != null) {
			StringTokenizer tokens = new StringTokenizer(extras, ",");
			do {
				if (!tokens.hasMoreTokens()) {
					break;
				}
				String test = tokens.nextToken().trim();
				if (test.length() > 0)  {
					initList.add(test);
				}
			}
			while (true);
		}
		for (String initClass : initList) {
			try {
				Class<?> clazz = Class.forName(initClass, true, Thread.currentThread().getContextClassLoader());
				Object initObject = clazz.newInstance();
				if (initObject instanceof IRDSServletInit) {
					Map<String, Class> map = ((IRDSServletInit)initObject).getServletCommandMap();
					for (Map.Entry<String, Class> entry : map.entrySet()) {
						loadServlet(entry.getKey(), entry.getValue());
					}
				}
				else {
					logger.error("Unable to load RDS initClass (does not implement IRDSServletInit): " + initClass);
				}
			}
			catch (ClassNotFoundException cnfe) {
				logger.error("Unable to load RDS initClass (ClassNotFoundException): " + initClass);
			}
			catch (IllegalAccessException iae) {
				logger.error("Unable to load RDS initClass (IllegalAccessException): " + initClass);
			}
			catch (InstantiationException instex) {
				logger.error("Unable to load RDS initClass (InstantiationException): " + initClass);
			}
		}
	}

	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			String action = req.getParameter("ACTION");
			if (action == null) {
				throw new ServletException("Could not locate Action attribute in request, RDS operation not defined");
			}
			action = action.toUpperCase();
			Servlet servlet = _servlets.get(action);
			if (servlet == null) {
				throw new ServletException("Operation not supported: " + action);
			}
			servlet.service(req, resp);
		}
		catch (ServletException e) {
			Throwable tmpRoot = e;
			Throwable root;
			for (root = null; root == null;) {
				if (tmpRoot instanceof ServletException) {
					ServletException se = (ServletException)tmpRoot;
					if (se.getRootCause() == null) {
						root = se;
					}
					else {
						tmpRoot = se.getRootCause();
					}
				}
				else {
					root = tmpRoot;
				}
			}

			RdsHttpResponseFormatter rl = new RdsHttpResponseFormatter();
			rl.setError(e.getMessage(), root);
			resp.getOutputStream().write(rl.getMessageBytes());
			log("Error occured!:" + new String(rl.getMessageBytes()));
		}
		catch (Throwable th) {
th.printStackTrace();
			RdsHttpResponseFormatter rl = new RdsHttpResponseFormatter();
			rl.setError(th.getMessage(), th);
			resp.getOutputStream().write(rl.getMessageBytes());
			log("Error occured!:" + new String(rl.getMessageBytes()));
			logger.error(th.getMessage(), th);
		}
	}

	@Override
	public void destroy() {
		for (Servlet s : _servlets.values()) {
			s.destroy();
		}
	}

	private void loadServlet(String name, Class<?> cls) throws ServletException {
		try {
			Servlet s = (Servlet)cls.newInstance();
			s.init(getServletConfig());
			_servlets.put(name.toUpperCase(), s);
		}
		catch (Exception e) {
			throw new ServletException(e);
		}
	}
}
