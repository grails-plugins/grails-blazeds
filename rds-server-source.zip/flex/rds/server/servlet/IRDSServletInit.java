package flex.rds.server.servlet;

import java.util.Map;

@SuppressWarnings("rawtypes")
public interface IRDSServletInit {
	Map getServletCommandMap();
}
