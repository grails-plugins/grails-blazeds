package flex.rds.server.servlet;

import java.io.IOException;

import javax.servlet.ServletException;

import flex.rds.server.RdsRequest;
import flex.rds.server.RdsResponse;
import flex.rds.server.RdsServlet;

public class IdeDefaultServlet extends RdsServlet {

	private static final long serialVersionUID = 0x9798309e3b67d6e1L;

	@Override
	protected void processCmd(RdsRequest req, RdsResponse resp) throws ServletException, IOException {
		resp.addMetaData("-500");
		resp.addMetaData("LCDS RDS Server Version: 1, 0, 0, 0");
		resp.addMetaData("ColdFusion Client Version: 7, 0, 0, 0");
		resp.addMetaData("1");
		if (!checkAuthorization(req.getUserName(), req.getPassword())) {
			resp.addMetaData("0");
		}
		else {
			resp.addMetaData("1");
		}
	}

	@Override
	public boolean isSecure() {
		return false;
	}
}
