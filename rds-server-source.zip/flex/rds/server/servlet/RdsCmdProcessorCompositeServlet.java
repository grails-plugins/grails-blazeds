package flex.rds.server.servlet;

import java.util.Hashtable;
import java.util.Map;

import javax.servlet.ServletException;

import flex.rds.server.RdsCmdProcessor;
import flex.rds.server.RdsServlet;

@SuppressWarnings({ "rawtypes", "serial" })
public abstract class RdsCmdProcessorCompositeServlet extends RdsServlet {

	private Hashtable<Object, RdsCmdProcessor> _processors = new Hashtable<Object, RdsCmdProcessor>();

	protected void addCmdProcessor(Object key, RdsCmdProcessor rcp) throws ServletException {
		rcp.init(this);
		_processors.put(key, rcp);
	}

	protected RdsCmdProcessor getCmdProcessor(Object key) {
		return _processors.get(key);
	}

	@Override
	public final void init() throws ServletException {
		doInit();
	}

	protected final Map getProcessors() {
		return _processors;
	}

	protected abstract void doInit() throws ServletException;
}
