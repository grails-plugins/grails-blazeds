package flex.rds.server.servlet.internal;

public class ArgumentInfo {
	public String argumentName;
	public TypeInfo argumentTypeInfo;
}
