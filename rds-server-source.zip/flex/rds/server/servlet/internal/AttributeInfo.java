package flex.rds.server.servlet.internal;

public class AttributeInfo {

	public String attriuteName;
	public TypeInfo attributeTypeInfo;

	public String getXML() {
		return "<property name=" + "\"" + attriuteName + "\"" + " " + "type=" + "\"" +
			attributeTypeInfo.fiberType + "\"" + "/>";
	}
}
