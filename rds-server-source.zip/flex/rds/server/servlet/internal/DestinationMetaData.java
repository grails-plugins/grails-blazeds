package flex.rds.server.servlet.internal;

import java.util.Properties;

public class DestinationMetaData {
	public ServiceMetaData serviceMetaData;
	public String destinationId;
	public String destinationClassType;
	public String destinationSource;
	public String factoryType;
	public String adapterName;
	public String adapterId;
	public String endPointUrl;
	public Properties properties = new Properties();
}
