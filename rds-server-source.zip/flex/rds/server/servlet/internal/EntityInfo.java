package flex.rds.server.servlet.internal;

import java.util.HashMap;
import java.util.Map;

public class EntityInfo {

	public TypeInfo entityTypeInfo;
	protected Map<String, AttributeInfo> attributeInfoMap = new HashMap<String, AttributeInfo>();

	public void addAttributeInfo(AttributeInfo dataServiceAttributeInfo) {
		attributeInfoMap.put(dataServiceAttributeInfo.attriuteName, dataServiceAttributeInfo);
	}

	public AttributeInfo getAttributeInfo(String attributeName) {
		return attributeInfoMap.get(attributeName);
	}

	public String getXML() {
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("<entity name=").append("\"").append(entityTypeInfo.fiberType).append("\"").append(">");
		stringBuilder.append("<annotation name=").append("\"").append("ServerProperties").append("\"").append(">")
				.append("<item name=").append("\"").append("RemoteClass").append("\"").append(">")
				.append(entityTypeInfo.javaType).append("</item></annotation>");
		for (AttributeInfo attributeInfo : attributeInfoMap.values()) {
			stringBuilder.append(attributeInfo.getXML());
		}

		stringBuilder.append("</entity>");
		return stringBuilder.toString();
	}
}
