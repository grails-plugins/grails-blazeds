package flex.rds.server.servlet.internal;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class FunctionInfo {

	public List<ArgumentInfo> argumentInfos = new ArrayList<ArgumentInfo>();
	public String functionName;
	public TypeInfo returnTypeInfo;

	public String getXML() {
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("<function name=").append("\"").append(functionName).append("\"").append(" ")
				.append("arguments=").append("\"");
		Iterator<ArgumentInfo> iterator = argumentInfos.iterator();
		do {
			if (!iterator.hasNext()) {
				break;
			}
			ArgumentInfo argumentInfo = iterator.next();
			stringBuilder.append(argumentInfo.argumentName).append(":").append(argumentInfo.argumentTypeInfo.fiberType);
			if (iterator.hasNext()) {
				stringBuilder.append(",");
			}
		}
		while (true);
		stringBuilder.append("\"").append(" ").append("return-type=").append("\"").append(returnTypeInfo.fiberType)
				.append("\"").append(">");
		if (!returnTypeInfo.fiberType.equals("opaque") && !returnTypeInfo.fiberType.equals("opaque[]")) {
			String annotationTagString = "<annotation name=\"analyze group\"><item name=\"analyzed\">true</item></annotation>";
			stringBuilder.append(annotationTagString);
		}
		stringBuilder.append("</function>");
		return stringBuilder.toString();
	}
}
