package flex.rds.server.servlet.internal;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import flex.messaging.Destination;
import flex.messaging.FactoryDestination;
import flex.messaging.MessageBroker;
import flex.messaging.endpoints.Endpoint;
import flex.messaging.services.Service;
import flex.messaging.services.ServiceAdapter;
import flex.messaging.services.http.HTTPProxyDestination;

public class JavaDestinationReader {

	public static ServiceMetaData[] getAllServicesMetaData(MessageBroker broker) {
		List<ServiceMetaData> servicesMetaData = new ArrayList<ServiceMetaData>();
		ServiceMetaData remotingServiceMetaData = new ServiceMetaData("flex.messaging.services.RemotingService",
				"remoting-service");
		ServiceMetaData dataServiceMetaData = new ServiceMetaData("flex.data.DataService", "data-service");
		ServiceMetaData messagingServiceMetaData = new ServiceMetaData("flex.messaging.services.MessageService",
				"message-service");
		ServiceMetaData proxyServiceMetaData = new ServiceMetaData("flex.messaging.services.HTTPProxyService",
				"proxy-service");
		servicesMetaData.add(remotingServiceMetaData);
		servicesMetaData.add(dataServiceMetaData);
		servicesMetaData.add(messagingServiceMetaData);
		servicesMetaData.add(proxyServiceMetaData);
		if (broker != null) {
			for (ServiceMetaData serviceMetaData : servicesMetaData) {
				Service service = broker.getServiceByType(serviceMetaData.getServiceName());
				if (service != null) {
					Map<String, Destination> destinations = service.getDestinations();
					Iterator<String> destinationsIterator = destinations.keySet().iterator();
					if (destinationsIterator != null)
						while (destinationsIterator.hasNext()) {
							Destination destination = destinations.get(destinationsIterator.next());
							if (destination != null) {
								DestinationMetaData destinationMetaData = new DestinationMetaData();
								serviceMetaData.addDestinationMetaData(destinationMetaData);
								List<String> channelIdList = destination.getChannels();
								Iterator<String> iter = channelIdList.iterator();
								do {
									if (!iter.hasNext())
										break;
									String channelId = iter.next();
									Endpoint endpoint = broker.getEndpoint(channelId);
									String endPointUrl = null;
									if (endpoint != null)
										endPointUrl = endpoint.getUrl();
									if (endPointUrl == null || endPointUrl.equals(""))
										continue;
									destinationMetaData.endPointUrl = endPointUrl;
									break;
								}
								while (true);
								destinationMetaData.destinationId = destination.getId();
								destinationMetaData.destinationClassType = destination.getClass().getName();
								destinationMetaData.adapterId = destination.getAdapter().getId();
								destinationMetaData.adapterName = destination.getAdapter().getClass().getName();
								if (destination instanceof FactoryDestination) {
									destinationMetaData.destinationSource = ((FactoryDestination)destination).getSource();
									destinationMetaData.factoryType = ((FactoryDestination)destination).getFactory().getClass()
											.getName();
								}
								else if (destination instanceof HTTPProxyDestination) {
									HTTPProxyDestination proxyDestination = (HTTPProxyDestination)destination;
									if (proxyDestination.getDefaultUrl() != null) {
										ServiceAdapter serviceAdapter = proxyDestination.getAdapter();
										String adapterClassName = serviceAdapter.getClass().getName();
										if (adapterClassName.equals("flex.messaging.services.http.HTTPProxyAdapter"))
											destinationMetaData.properties.put("url", proxyDestination.getDefaultUrl());
										else if (adapterClassName.equals("flex.messaging.services.http.SOAPProxyAdapter"))
											destinationMetaData.properties.put("wsdl", proxyDestination.getDefaultUrl());
									}
								}
							}
						}
				}
			}

		}
		return servicesMetaData.toArray(new ServiceMetaData[0]);
	}

	public static String getDesinationsAsXMLString(ServiceMetaData servicesMetaDatas[]) {
		return createXML(servicesMetaDatas);
	}

	public static String getDesinationsAsXMLString(MessageBroker broker) {
		return createXML(getAllServicesMetaData(broker));
	}

	public static String createXML(ServiceMetaData serviceInfos[]) {
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
		stringBuilder.append("<services>");
		for (ServiceMetaData serviceInfo : serviceInfos) {
			stringBuilder.append("<service type=\"").append(serviceInfo.getServiceName())
					.append("\"").append(" id=").append("\"").append(serviceInfo.getServiceId()).append("\"").append(">");
			stringBuilder.append("<destinations>");
			DestinationMetaData destinationsMetaData[] = serviceInfo.getDestinationsMetaData();
			for (DestinationMetaData destinationMetaData : destinationsMetaData) {
				stringBuilder.append("<destination>");
				stringBuilder.append("<id>").append(destinationMetaData.destinationId).append("</id>");
				stringBuilder.append("<destinationClassType>").append(destinationMetaData.destinationClassType).append("</destinationClassType>");
				stringBuilder.append("<destinationSource>").append(destinationMetaData.destinationSource).append("</destinationSource>");
				stringBuilder.append("<factoryType>").append(destinationMetaData.factoryType).append("</factoryType>");
				stringBuilder.append("<adapterId>").append(destinationMetaData.adapterId).append("</adapterId>");
				stringBuilder.append("<adapterName>").append(destinationMetaData.adapterName).append("</adapterName>");
				stringBuilder.append("<endPointUrl>").append(destinationMetaData.endPointUrl).append("</endPointUrl>");
				if (destinationMetaData.properties.size() > 0) {
					Enumeration<?> enumeration = destinationMetaData.properties.propertyNames();
					stringBuilder.append("<properties>");
					String key;
					for (; enumeration.hasMoreElements(); stringBuilder
							.append("<").append(key).append(">")
							.append(destinationMetaData.properties.getProperty(key))
							.append("</").append(key).append(">")) {
						key = (String)enumeration.nextElement();
					}

					stringBuilder.append("</properties>");
				}
				stringBuilder.append("</destination>");
			}

			stringBuilder.append("</destinations>");
			stringBuilder.append("</service>");
		}

		stringBuilder.append("</services>");
		return stringBuilder.toString();
	}
}
