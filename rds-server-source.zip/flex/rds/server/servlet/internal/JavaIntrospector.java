package flex.rds.server.servlet.internal;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import flex.messaging.FactoryDestination;
import flex.messaging.MessageBroker;
import flex.messaging.services.Service;
import flex.messaging.services.remoting.adapters.JavaAdapter;
import flex.messaging.services.remoting.adapters.RemotingMethod;
import flex.rds.server.util.RB;
import groovy.lang.MetaClass;

@SuppressWarnings({ "unchecked", "rawtypes" })
public class JavaIntrospector {

	private Class classObject;
	private String _destinationId;
	private Set<Method> publicMethods = new HashSet<Method>();
	private Set typeSet = new HashSet();
	private MessageBroker _messageBroker;
	private ModelInfo modelInfo = new ModelInfo();

	public JavaIntrospector(MessageBroker messageBroker, String destinationId) {
		_messageBroker = messageBroker;
		_destinationId = destinationId;
	}

	public String getClassDataAsXMLString() throws LCDSIntrospectionException {
		if (_destinationId == null) {
			return null;
		}
		Service service = _messageBroker.getServiceByType("flex.messaging.services.RemotingService");
		FactoryDestination destination = (FactoryDestination)service.getDestination(_destinationId);
		if (destination == null) {
			throw new LCDSIntrospectionException(RB.getString(this,
					"LCDSJavaIntrospectorServlet.DestinationDoesnotExistMessage", _destinationId));
		}
		JavaAdapter javaAdapter = null;
		if (destination.getAdapter() instanceof JavaAdapter)
			javaAdapter = (JavaAdapter)destination.getAdapter();
		String className = destination.getSource();
		try {
			classObject = Class.forName(className, true, Thread.currentThread().getContextClassLoader());
			if (classObject.isInterface())
				throw new LCDSIntrospectionException(RB.getString(this,
						"LCDSJavaIntrospectorServlet.InterfaceIntrospectionExceptionMessage", className));
		}
		catch (ClassNotFoundException e) {
			throw new LCDSIntrospectionException(RB.getString(this,
					"LCDSJavaIntrospectorServlet.ClassNotFoundExceptionMessage", className));
		}
		catch (SecurityException e) {
			throw new LCDSIntrospectionException(RB.getString(this,
					"LCDSJavaIntrospectorServlet.SecurityExceptionMessage", classObject.getCanonicalName()));
		}
		if (Modifier.isAbstract(classObject.getModifiers()))
			throw new LCDSIntrospectionException(
					RB.getString(this, "LCDSJavaIntrospectorServlet.AbstractClassIntrospectionExceptionMessage",
							classObject.getCanonicalName()));
		Set includedMethodNameSet = new HashSet();
		Set excludedMethodNameSet = new HashSet();
		if (javaAdapter != null) {
			Iterator excludeMethodIterator = javaAdapter.getExcludeMethodIterator();
			Iterator includeMethodIterator = javaAdapter.getIncludeMethodIterator();
			if (includeMethodIterator != null) {
				RemotingMethod includedRemotingMethod;
				for (; includeMethodIterator.hasNext(); includedMethodNameSet.add(includedRemotingMethod.getName()))
					includedRemotingMethod = (RemotingMethod)includeMethodIterator.next();

			}
			if (excludeMethodIterator != null) {
				RemotingMethod excludedRemotingMethod;
				for (; excludeMethodIterator.hasNext(); excludedMethodNameSet.add(excludedRemotingMethod.getName()))
					excludedRemotingMethod = (RemotingMethod)excludeMethodIterator.next();

			}
		}
		Method methods[] = classObject.getMethods();
		if (methods != null) {
			Set tempMethodNameSet = new HashSet();
			for (int i = 0; i < methods.length; i++) {
				Method method = methods[i];
				if (includedMethodNameSet.size() > 0 && !includedMethodNameSet.contains(method.getName())
						|| excludedMethodNameSet.contains(method.getName()) || method.getDeclaringClass() == Object.class)
					continue;
				if (!tempMethodNameSet.add(method.getName()))
					throw new LCDSIntrospectionException(RB.getString(this,
							"LCDSJavaIntrospectorServlet.OverloadedMethodsUnsupportedException", className));
				publicMethods.add(method);
			}
		}

		Iterator i = publicMethods.iterator();
		do {
			if (!i.hasNext())
				break;
			Method method = (Method)i.next();
			Class returnType = method.getReturnType();
			Type genericReturnType = method.getGenericReturnType();
			introspect(genericReturnType, returnType);
			Class parameters[] = method.getParameterTypes();
			Type genericparameters[] = method.getGenericParameterTypes();
			if (parameters != null && genericparameters != null) {
				int p = 0;
				while (p < parameters.length) {
					introspect(genericparameters[p], parameters[p]);
					p++;
				}
			}
		}
		while (true);
		ServiceInfo serviceInfo = createServiceInfo();
		modelInfo.serviceInfo = serviceInfo;
		return modelInfo.getXML();
	}

	private void introspect(Type genericType, Class class1) throws LCDSIntrospectionException {
		if (JavatoFiberTypeMap.isJavaCollection(class1)) {
			if (genericType instanceof ParameterizedType) {
				ParameterizedType parameterizedType = (ParameterizedType)genericType;
				Type typeArguments[] = parameterizedType.getActualTypeArguments();
				if (typeArguments != null && typeArguments.length == 1) {
					Type firstTypeArgument = typeArguments[0];
					if (firstTypeArgument instanceof ParameterizedType) {
						ParameterizedType firstParametterizedTypeArgument = (ParameterizedType)firstTypeArgument;
						Type firstRawTypeArgument = firstParametterizedTypeArgument.getRawType();
						if (firstRawTypeArgument instanceof Class)
							introspect((Class)firstRawTypeArgument);
					}
					else if (firstTypeArgument instanceof Class)
						introspect((Class)firstTypeArgument);
				}
			}
		}
		else {
			introspect(class1);
		}
	}

	private ServiceInfo createServiceInfo() {
		ServiceInfo serviceInfo = new ServiceInfo();
		TypeInfo serviceTypeInfo = new TypeInfo();
		serviceInfo.serviceTypeInfo = serviceTypeInfo;
		serviceTypeInfo.fiberType = JavaIntrospectorUtil.getFiberEquivalentType(null, classObject) + "_Service";
		serviceTypeInfo.javaType = classObject.getCanonicalName();
		serviceInfo.functionInfos = new ArrayList();
		for (Method method : publicMethods) {
			FunctionInfo functionInfo = new FunctionInfo();
			serviceInfo.functionInfos.add(functionInfo);
			functionInfo.functionName = method.getName();
			TypeInfo returnTypeInfo = new TypeInfo();
			functionInfo.returnTypeInfo = returnTypeInfo;
			returnTypeInfo.javaType = method.getReturnType().getCanonicalName();
			returnTypeInfo.fiberType = JavaIntrospectorUtil.getFiberEquivalentType(method.getGenericReturnType(),
					method.getReturnType());
			Class parameterTypes[] = method.getParameterTypes();
			Type genericParameterTypes[] = method.getGenericParameterTypes();
			int p = 0;
			while (p < parameterTypes.length) {
				Class parameterType = parameterTypes[p];
				Type genericParameterType = genericParameterTypes[p];
				ArgumentInfo argumentInfo = new ArgumentInfo();
				functionInfo.argumentInfos.add(argumentInfo);
				TypeInfo argumentTypeInfo = new TypeInfo();
				argumentInfo.argumentTypeInfo = argumentTypeInfo;
				argumentTypeInfo.javaType = parameterType.getCanonicalName();
				argumentTypeInfo.fiberType = JavaIntrospectorUtil.getFiberEquivalentType(genericParameterType,
						parameterType);
				argumentInfo.argumentName = "arg" + p;
				p++;
			}
		}

		return serviceInfo;
	}

	private void introspect(Class class1) throws LCDSIntrospectionException {
		if (class1 == null)
			return;
		if (class1.isArray()) {
			Class componentType = class1.getComponentType();
			if (componentType == null || componentType.isArray()) {
				return;
			}
			introspect(componentType);
			return;
		}

		if (JavaIntrospectorUtil.addToTypeSet(class1, typeSet)) {
			Set propertySet = new HashSet();
			Field[] fields = class1.getFields();
			for (int i = 0; i < fields.length; i++) {
				Field field = fields[i];
				PropertyStructure property = new PropertyStructure();
				property.propertyName = field.getName();
				property.propertyClass = field.getType();
				property.genericType = field.getGenericType();
				int fieldModifier = field.getModifiers();
				if (JavaIntrospectorUtil.isPublicField(fieldModifier)) {
					propertySet.add(property);
					introspect(field.getGenericType(), field.getType());
				}
			}

			BeanInfo beanInfo = null;
			try {
				beanInfo = Introspector.getBeanInfo(class1);
			}
			catch (IntrospectionException e) {
				// ignored
			}
			if (beanInfo != null) {
				PropertyDescriptor propertyDescriptors[] = beanInfo.getPropertyDescriptors();
				if (propertyDescriptors != null) {
					for (int i = 0; i < propertyDescriptors.length; i++) {
						PropertyDescriptor propertyDescriptor = propertyDescriptors[i];
						if (propertyDescriptor == null)
							continue;
						Method readMethod = propertyDescriptor.getReadMethod();
						if (readMethod != null &&
								JavaIntrospectorUtil.isPublicAccessor(readMethod.getModifiers()) &&
								(propertyDescriptor.getPropertyType() != Class.class || !propertyDescriptor.getName().equals("class")) &&
								propertyDescriptor.getPropertyType() != MetaClass.class) {
							PropertyStructure property = new PropertyStructure();
							property.propertyName = propertyDescriptor.getName();
							property.propertyClass = propertyDescriptor.getPropertyType();
							property.genericType = readMethod.getGenericReturnType();
							propertySet.add(property);
							Type genericReturnType = readMethod.getGenericReturnType();
							introspect(genericReturnType, propertyDescriptor.getPropertyType());
						}
					}

				}
			}
			EntityInfo entityInfo = createEntityInfo(class1, propertySet);
			modelInfo.addEntityInfo(class1, entityInfo);
		}
	}

	private EntityInfo createEntityInfo(Class class1, Set propertySet) {
		EntityInfo dataServiceEntityInfo = new EntityInfo();
		PropertyStructure property;
		for (Iterator i = propertySet.iterator(); i.hasNext(); dataServiceEntityInfo
				.addAttributeInfo(createAttributeInfo(property)))
			property = (PropertyStructure)i.next();

		TypeInfo typeInfo = new TypeInfo();
		typeInfo.fiberType = JavaIntrospectorUtil.getFiberEquivalentType(null, class1);
		typeInfo.javaType = class1.getCanonicalName();
		dataServiceEntityInfo.entityTypeInfo = typeInfo;
		return dataServiceEntityInfo;
	}

	private AttributeInfo createAttributeInfo(PropertyStructure property) {
		AttributeInfo dataServiceAttributeInfo = new AttributeInfo();
		dataServiceAttributeInfo.attriuteName = property.propertyName;
		TypeInfo typeInfo = new TypeInfo();
		typeInfo.fiberType = JavaIntrospectorUtil.getFiberEquivalentType(property.genericType, property.propertyClass);
		typeInfo.javaType = property.propertyClass.getCanonicalName();
		dataServiceAttributeInfo.attributeTypeInfo = typeInfo;
		return dataServiceAttributeInfo;
	}
}
