package flex.rds.server.servlet.internal;

public interface JavaIntrospectorConstants {
	String DOUBLE_QUOTES = "\"";
	String SPACE = " ";
	String opaqeArray = "opaque[]";
}
