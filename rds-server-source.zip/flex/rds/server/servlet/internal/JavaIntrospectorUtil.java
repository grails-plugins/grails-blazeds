package flex.rds.server.servlet.internal;

import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Set;

import flex.messaging.MessageBroker;
import flex.messaging.config.ChannelSettings;
import flex.messaging.services.Service;

@SuppressWarnings({ "unchecked", "rawtypes" })
public class JavaIntrospectorUtil {

	public static boolean isPublicField(int modifiers) {
		return Modifier.isPublic(modifiers) && !Modifier.isStatic(modifiers) && !Modifier.isTransient(modifiers);
	}

	public static boolean isPublicAccessor(int modifiers) {
		return Modifier.isPublic(modifiers) && !Modifier.isStatic(modifiers);
	}

	public static String getFiberEquivalentType(Type genericType, Class class1) {
		if (JavatoFiberTypeMap.isJavaCollection(class1) && (genericType instanceof ParameterizedType)) {
			ParameterizedType parameterizedType = (ParameterizedType)genericType;
			Type typeArguments[] = parameterizedType.getActualTypeArguments();
			if (typeArguments != null && typeArguments.length == 1) {
				Type firstTypeArgument = typeArguments[0];
				if (firstTypeArgument instanceof ParameterizedType) {
					ParameterizedType firstParametterizedTypeArgument = (ParameterizedType)firstTypeArgument;
					Type firstRawTypeArgument = firstParametterizedTypeArgument.getRawType();
					if (firstRawTypeArgument instanceof Class) {
						Class firstClassArgument = (Class)firstRawTypeArgument;
						if (!firstClassArgument.isArray() && !JavatoFiberTypeMap.isJavaCollection(firstClassArgument))
							return getFiberEquivalentType(firstTypeArgument, firstClassArgument) + "[]";
					}
				}
				else if (firstTypeArgument instanceof Class) {
					Class firstClassArgument = (Class)firstTypeArgument;
					if (!firstClassArgument.isArray() && !JavatoFiberTypeMap.isJavaCollection(firstClassArgument)) {
						return getFiberEquivalentType(firstClassArgument) + "[]";
					}
				}
			}
		}
		return getFiberEquivalentType(class1);
	}

	private static String getFiberEquivalentType(Class class1) {
		if (class1.isArray() && !JavatoFiberTypeMap.contains(class1.getCanonicalName())) {
			if (class1.getComponentType().isArray() || JavatoFiberTypeMap.isJavaCollection(class1.getComponentType())) {
				return "opaque[]";
			}
			return getFiberEquivalentType(class1.getComponentType()) + "[]";
		}

		if (JavatoFiberTypeMap.isJavaCollection(class1)) {
			return "opaque[]";
		}
		if (JavatoFiberTypeMap.isJavaMap(class1) || JavatoFiberTypeMap.isJavaDictionary(class1)
				|| JavatoFiberTypeMap.isJavaDocument(class1)) {
			return "opaque";
		}
		if (JavatoFiberTypeMap.isJavaEnum(class1) || JavatoFiberTypeMap.isJavaBigDecimal(class1)
				|| JavatoFiberTypeMap.isJavaBigInteger(class1)) {
			return "string";
		}
		if (JavatoFiberTypeMap.contains(class1.getCanonicalName())) {
			return JavatoFiberTypeMap.get(class1.getCanonicalName());
		}
		String fiberEquivalentFieldType = class1.getSimpleName();
		if (Character.isLowerCase(fiberEquivalentFieldType.charAt(0))) {
			fiberEquivalentFieldType = String.valueOf(fiberEquivalentFieldType.charAt(0)).toUpperCase() +
					fiberEquivalentFieldType.substring(1, fiberEquivalentFieldType.length());
		}
		return fiberEquivalentFieldType;
	}

	public static boolean addToTypeSet(Class class1, Set typeSet) {
		if (class1 == null || JavatoFiberTypeMap.contains(class1.getCanonicalName()) || typeSet.contains(class1)
				|| JavatoFiberTypeMap.isJavaCollection(class1) || JavatoFiberTypeMap.isJavaMap(class1)
				|| JavatoFiberTypeMap.isJavaEnum(class1) || JavatoFiberTypeMap.isJavaBigDecimal(class1)
				|| JavatoFiberTypeMap.isJavaBigInteger(class1) || JavatoFiberTypeMap.isJavaDictionary(class1)
				|| JavatoFiberTypeMap.isJavaDocument(class1))
			return false;
		if (class1.isArray()) {
			addToTypeSet(class1.getComponentType(), typeSet);
		}
		typeSet.add(class1);
		return true;
	}

	public static String getDefaultChannels(MessageBroker messageBroker, String serviceId) {
		Service service = messageBroker.getService(serviceId);
		List<String> defaultChannels = service.getDefaultChannels();
		StringBuilder uris = new StringBuilder();
		for (String defaultChannelUriString : defaultChannels) {
			ChannelSettings channelSettings = messageBroker.getChannelSettings(defaultChannelUriString);
			String channelUri = channelSettings.getUri();
			if (uris.length() == 0) {
				uris.append("<").append(channelUri).append("<").append(channelSettings.getClientType());
				return uris.toString();
			}
		}

		return uris.toString();
	}
}
