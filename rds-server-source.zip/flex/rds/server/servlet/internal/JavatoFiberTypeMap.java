package flex.rds.server.servlet.internal;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Map;

import org.w3c.dom.Document;

public class JavatoFiberTypeMap {

	private static String defaultType = "opaque";
	private static Map<String, String> typeMap = new HashMap<String, String>();

	static {
		addTypemapping(Object.class.getCanonicalName(), "opaque");
		addTypemapping(String.class.getCanonicalName(), "string");
		addTypemapping(Integer.class.getCanonicalName(), "integer");
		addTypemapping(Boolean.class.getCanonicalName(), "boolean");
		addTypemapping(Float.class.getCanonicalName(), "float");
		addTypemapping(Double.class.getCanonicalName(), "double");
		addTypemapping(Long.class.getCanonicalName(), "long");
		addTypemapping(Character.class.getCanonicalName(), "char");
		addTypemapping(Byte.class.getCanonicalName(), "integer");
		addTypemapping(Date.class.getCanonicalName(), "date");
		addTypemapping(Calendar.class.getCanonicalName(), "date");
		addTypemapping(Short.class.getCanonicalName(), "integer");
		addTypemapping(Integer.TYPE.getCanonicalName(), "integer");
		addTypemapping(Boolean.TYPE.getCanonicalName(), "boolean");
		addTypemapping(Float.TYPE.getCanonicalName(), "float");
		addTypemapping(Double.TYPE.getCanonicalName(), "double");
		addTypemapping(Long.TYPE.getCanonicalName(), "long");
		addTypemapping(Character.TYPE.getCanonicalName(), "char");
		addTypemapping(Byte.TYPE.getCanonicalName(), "integer");
		addTypemapping(Void.TYPE.getCanonicalName(), "void");
		addTypemapping(Short.TYPE.getCanonicalName(), "integer");
		addTypemapping(byte[].class.getCanonicalName(), "blob");
		addTypemapping(Byte[].class.getCanonicalName(), "blob");
	}

	public static String get(String key) {
		String type = typeMap.get(key);
		if (type == null) {
			return defaultType;
		}
		return type;
	}

	public static boolean contains(String CFType) {
		return typeMap.containsKey(CFType);
	}

	private static void addTypemapping(String name, String str) {
		typeMap.put(name, str);
	}

	public static boolean isJavaMap(Class<?> class1) {
		return Map.class.isAssignableFrom(class1);
	}

	public static boolean isJavaCollection(Class<?> class1) {
		return Collection.class.isAssignableFrom(class1);
	}

	public static boolean isJavaEnum(Class<?> class1) {
		return Enum.class.isAssignableFrom(class1);
	}

	public static boolean isJavaBigDecimal(Class<?> class1) {
		return BigDecimal.class.isAssignableFrom(class1);
	}

	public static boolean isJavaBigInteger(Class<?> class1) {
		return BigInteger.class.isAssignableFrom(class1);
	}

	public static boolean isJavaDictionary(Class<?> class1) {
		return Dictionary.class.isAssignableFrom(class1);
	}

	public static boolean isJavaDocument(Class<?> class1) {
		return Document.class.isAssignableFrom(class1);
	}
}
