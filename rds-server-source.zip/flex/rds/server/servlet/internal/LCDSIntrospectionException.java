package flex.rds.server.servlet.internal;

public class LCDSIntrospectionException extends Exception {

	private static final long serialVersionUID = 1L;
	private String message;

	public LCDSIntrospectionException(String message) {
		super(message);
		this.message = null;
		this.message = message;
	}

	public LCDSIntrospectionException(Exception e) {
		super(e);
		message = null;
	}

	@Override
	public String getMessage() {
		if (message == null) {
			return super.getMessage();
		}
		return message;
	}
}
