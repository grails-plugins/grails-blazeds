package flex.rds.server.servlet.internal;

import java.util.HashMap;
import java.util.Map;

@SuppressWarnings("rawtypes")
public class ModelInfo {

	private Map<Class, EntityInfo> entityInfoMap = new HashMap<Class, EntityInfo>();
	public ServiceInfo serviceInfo;

	public String getXML() {
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("<?xml version=\"1.0\" encoding=\"utf-8\"?>")
				.append("<model xmlns=\"http://ns.adobe.com/Fiber/1.0\">").append(serviceInfo.getXML());
		for (EntityInfo entityInfo : entityInfoMap.values()) {
			stringBuilder.append(entityInfo.getXML());
		}
		stringBuilder.append("</model>");
		return stringBuilder.toString();
	}

	public void addEntityInfo(Class type, EntityInfo entityInfo) {
		entityInfoMap.put(type, entityInfo);
	}

	public EntityInfo getEntityInfo(Class type) {
		return entityInfoMap.get(type);
	}
}
