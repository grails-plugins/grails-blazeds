package flex.rds.server.servlet.internal;

import java.lang.reflect.Type;

public class PropertyStructure {
	public String propertyName;
	public Type genericType;
	public Class<?> propertyClass;
}
