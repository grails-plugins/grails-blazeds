package flex.rds.server.servlet.internal;

import java.util.ArrayList;
import java.util.List;

public class ServiceInfo {

	public TypeInfo serviceTypeInfo;
	public List<FunctionInfo> functionInfos = new ArrayList<FunctionInfo>();

	public String getXML() {
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("<service name=").append("\"").append(serviceTypeInfo.fiberType).append("\"").append(">");
		for (FunctionInfo functionInfo : functionInfos) {
			stringBuilder.append(functionInfo.getXML());
		}
		stringBuilder.append("</service>");
		return stringBuilder.toString();
	}
}
