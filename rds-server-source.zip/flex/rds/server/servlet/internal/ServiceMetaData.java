package flex.rds.server.servlet.internal;

import java.util.HashSet;
import java.util.Set;

public class ServiceMetaData {

	private String serviceName;
	private String serviceId;
	private Set<DestinationMetaData> destinatioMetaDataSet;

	public ServiceMetaData(String serviceName, String serviceId) {
		destinatioMetaDataSet = new HashSet<DestinationMetaData>();
		this.serviceName = serviceName;
		this.serviceId = serviceId;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getServiceId() {
		return serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	public void addDestinationMetaData(DestinationMetaData destinationMetaData) {
		destinatioMetaDataSet.add(destinationMetaData);
	}

	public DestinationMetaData[] getDestinationsMetaData() {
		return destinatioMetaDataSet.toArray(new DestinationMetaData[0]);
	}
}
