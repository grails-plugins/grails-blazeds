package flex.rds.server.servlet.internal;

public class TypeInfo {
	public String javaType;
	public String fiberType;
}
