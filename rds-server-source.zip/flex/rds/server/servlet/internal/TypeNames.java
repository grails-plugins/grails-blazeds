package flex.rds.server.servlet.internal;

public interface TypeNames {
	String BOOLEAN = "boolean";
	String CHAR = "char";
	String DATE = "date";
	String DOUBLE = "double";
	String FLOAT = "float";
	String INTEGER = "integer";
	String LONG = "long";
	String OPAQUE = "opaque";
	String STRING = "string";
	String VOID = "void";
	String BLOB = "blob";
}
