package flex.rds.server.util;

import java.io.IOException;
import java.io.InputStream;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.text.MessageFormat;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.Properties;

@SuppressWarnings({ "unchecked", "rawtypes" })
public final class RB {

	private Hashtable propertyCache;
	private static final String BASE_NAME = "resource";
	private static final String PROPERTY_EXT = ".properties";
	private String basePropertyFileName;
	private Properties resourceProperties;

	private RB(Object caller, String name, Locale locale) throws MissingResourceException {
		propertyCache = new Hashtable();
		ClassLoader cl = null;
		if (caller != null) {
			Class c;
			if (caller instanceof Class)
				c = (Class)caller;
			else
				c = caller.getClass();
			cl = c.getClassLoader();
			if (name.indexOf("/") == -1) {
				String fullName = c.getName();
				int pos = fullName.lastIndexOf(".");
				if (pos > 0) {
					name = fullName.substring(0, pos + 1).replace('.', '/') + name;
				}
			}
		}
		Locale defaultLocale = Locale.getDefault();
		if (locale != null && locale.equals(defaultLocale)) {
			locale = null;
		}
		loadProperties(name, cl, locale, defaultLocale);
	}

	private String getString(String key, Object array[]) throws MissingResourceException {
		if (resourceProperties == null) {
			return null;
		}
		String msg = resourceProperties.getProperty(key);
		if (msg == null) {
			return null;
		}
		try {
			return MessageFormat.format(msg, array);
		}
		catch (IllegalArgumentException e) {
			throw new MissingResourceException(
					"Can't find resource key \"" + key + "\" in base name " + basePropertyFileName,
					basePropertyFileName, key);
		}
	}

	private void loadProperties(String basename, ClassLoader loader, Locale locale, Locale defaultLocale)
			throws MissingResourceException {
		String loaderName = "";
		if (loader != null) {
			loaderName = ":" + loader.hashCode();
		}
		String cacheKey = basename + ":" + locale + ":" + defaultLocale + loaderName;
		Properties p = (Properties)propertyCache.get(cacheKey);
		basePropertyFileName = basename + PROPERTY_EXT;
		if (p == null) {
			if (locale != null) {
				p = loadProperties(basename, loader, locale, p);
			}
			if (defaultLocale != null) {
				p = loadProperties(basename, loader, defaultLocale, p);
			}
			p = merge(p, loadProperties(basePropertyFileName, loader));
			if (p == null) {
				throw new MissingResourceException(
						"Can't find resource for base name " + basePropertyFileName,
						basePropertyFileName, "");
			}
			propertyCache.put(cacheKey, p);
		}
		resourceProperties = p;
	}

	private Properties loadProperties(String basename, ClassLoader loader, Locale locale, Properties props) {
		String language = locale.getLanguage();
		String country = locale.getCountry();
		String variant = locale.getVariant();
		if (variant != null && variant.trim().length() == 0)
			variant = null;
		if (language != null) {
			if (country != null) {
				if (variant != null)
					props = merge(
							props,
							loadProperties(basename + "_" + language + "_" + country + "_" + variant + PROPERTY_EXT, loader));
				props = merge(
						props,
						loadProperties(basename + "_" + language + "_" + country + PROPERTY_EXT, loader));
			}
			props = merge(
					props,
					loadProperties(basename + "_" + language + PROPERTY_EXT, loader));
		}
		return props;
	}

	private Properties loadProperties(final String resname, final ClassLoader loader) {
		Properties ps = null;
		try {
			ps = (Properties)AccessController.doPrivileged(new PrivilegedExceptionAction() {
				public Object run() throws Exception {
					Properties props = null;
					InputStream in = null;
					try {
						if (loader != null) {
							in = loader.getResourceAsStream(resname);
						}
						if (in == null) {
							in = ClassLoader.getSystemResourceAsStream(resname);
						}
						if (in != null) {
							props = new Properties();
							try {
								props.load(in);
							}
							catch (IOException ex) {
								props = null;
							}
						}
						if (in != null)
							try {
								in.close();
							}
							catch (Exception ex) {
								// ignored
							}
						return props;
					}
					finally {
						if (in != null)
							try { in.close(); }
							catch (Exception ex) {
								// ignored
							}
					}
				}
			});
		}
		catch (PrivilegedActionException ex) {
			// ignored
		}
		return ps;
	}

	private Properties merge(Properties p1, Properties p2) {
		if (p1 == null && p2 == null)
			return null;
		if (p1 == null)
			return p2;
		if (p2 == null)
			return p1;
		Enumeration keysEnum = p2.keys();
		do {
			if (!keysEnum.hasMoreElements())
				break;
			String key = (String)keysEnum.nextElement();
			if (p1.getProperty(key) == null)
				p1.put(key, p2.getProperty(key));
		}
		while (true);
		return p1;
	}

	public static String getString(Object caller, String key) throws MissingResourceException {
		return getMessage(caller, BASE_NAME, null, key, null);
	}

	public static String getString(Object caller, String key, Object arg0) throws MissingResourceException {
		Object o[] = new Object[1];
		o[0] = arg0;
		return getMessage(caller, BASE_NAME, null, key, o);
	}

	public static String getString(Object caller, String key, Object arg0, Object arg1) throws MissingResourceException {
		Object o[] = new Object[2];
		o[0] = arg0;
		o[1] = arg1;
		return getMessage(caller, BASE_NAME, null, key, o);
	}

	public static String getString(Object caller, String key, Object arg0, Object arg1, Object arg2)
			throws MissingResourceException {
		Object o[] = new Object[3];
		o[0] = arg0;
		o[1] = arg1;
		o[2] = arg2;
		return getMessage(caller, BASE_NAME, null, key, o);
	}

	public static String getString(Object caller, String key, Object arg0, Object arg1, Object arg2, Object arg3)
			throws MissingResourceException {
		Object o[] = new Object[4];
		o[0] = arg0;
		o[1] = arg1;
		o[2] = arg2;
		o[3] = arg3;
		return getMessage(caller, BASE_NAME, null, key, o);
	}

	public static String getString(Object caller, String key, Object arg0, Object arg1, Object arg2, Object arg3,
			Object arg4) throws MissingResourceException {
		Object o[] = new Object[5];
		o[0] = arg0;
		o[1] = arg1;
		o[2] = arg2;
		o[3] = arg3;
		o[4] = arg4;
		return getMessage(caller, BASE_NAME, null, key, o);
	}

	public static String getString(Object caller, String key, Object args[]) throws MissingResourceException {
		return getMessage(caller, BASE_NAME, null, key, args);
	}

	public static String getString(Object caller, Locale locale, String key) throws MissingResourceException {
		return getMessage(caller, BASE_NAME, locale, key, null);
	}

	public static String getString(Object caller, Locale locale, String key, Object arg0)
			throws MissingResourceException {
		Object o[] = new Object[1];
		o[0] = arg0;
		return getMessage(caller, BASE_NAME, locale, key, o);
	}

	public static String getString(Object caller, Locale locale, String key, Object arg0, Object arg1)
			throws MissingResourceException {
		Object o[] = new Object[2];
		o[0] = arg0;
		o[1] = arg1;
		return getMessage(caller, BASE_NAME, locale, key, o);
	}

	public static String getString(Object caller, Locale locale, String key, Object arg0, Object arg1, Object arg2)
			throws MissingResourceException {
		Object o[] = new Object[3];
		o[0] = arg0;
		o[1] = arg1;
		o[2] = arg2;
		return getMessage(caller, BASE_NAME, locale, key, o);
	}

	public static String getString(Object caller, Locale locale, String key, Object arg0, Object arg1, Object arg2,
			Object arg3) throws MissingResourceException {
		Object o[] = new Object[4];
		o[0] = arg0;
		o[1] = arg1;
		o[2] = arg2;
		o[3] = arg3;
		return getMessage(caller, BASE_NAME, locale, key, o);
	}

	public static String getString(Object caller, Locale locale, String key, Object arg0, Object arg1, Object arg2,
			Object arg3, Object arg4) throws MissingResourceException {
		Object o[] = new Object[5];
		o[0] = arg0;
		o[1] = arg1;
		o[2] = arg2;
		o[3] = arg3;
		o[4] = arg4;
		return getMessage(caller, BASE_NAME, locale, key, o);
	}

	public static String getString(Object caller, Locale locale, String key, Object args[])
			throws MissingResourceException {
		return getMessage(caller, BASE_NAME, locale, key, args);
	}

	public static String getMessage(Object caller, String basename, Locale locale, String key, Object args[])
			throws MissingResourceException {
		String msg = null;
		MissingResourceException firstEx = null;
		Class curClass = null;
		if (caller != null)
			if (caller instanceof Class)
				curClass = (Class)caller;
			else
				curClass = caller.getClass();
		while (msg == null) {
			String fullName;
			if (curClass != null) {
				String pkgName = curClass.getName();
				int pos = pkgName.lastIndexOf(".");
				if (pos > 0) {
					fullName = pkgName.substring(0, pos + 1).replace('.', '/') + basename;
				}
				else {
					fullName = basename;
				}
			}
			else {
				fullName = basename;
			}
			try {
				RB rb = new RB(caller, fullName, locale);
				msg = rb.getString(key, args);
			}
			catch (MissingResourceException ex) {
				if (curClass == null)
					throw ex;
				if (firstEx == null)
					firstEx = ex;
				Class sc = curClass.getSuperclass();
				if (sc == null)
					throw firstEx;
				String cname = sc.getName();
				if (cname.startsWith("java.") || cname.startsWith("javax."))
					throw firstEx;
				curClass = sc;
			}
		}
		return msg;
	}
}
